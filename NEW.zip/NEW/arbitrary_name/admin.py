from django.contrib import admin
from .models import Human, Profession


class HumanAdmin(admin.ModelAdmin):
    list_display = ('id', 'Prof', 'First_name', 'Last_name2', 'Last_name', 'Residence', 'Birthdate',
                    'Characteristic', 'Photo', 'Registration')
    list_display_links = ('id', 'Last_name2', 'Birthdate')
    search_fields = ('First_name', 'Last_name2', 'Residence', 'Birthdate', 'Characteristic', 'Registration')
    list_filter = ['Prof']
    list_editable = ['Prof']


class ProfessionAdmin(admin.ModelAdmin):
    list_display = ('id', 'title')
    list_display_links = ('id', 'title')


admin.site.register(Human, HumanAdmin)
admin.site.register(Profession, ProfessionAdmin)
