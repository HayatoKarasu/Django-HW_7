from django.shortcuts import render

from .models import Human


def index(request):
    human = Human.objects.all()
    context = {
        'human': human,
        'title': 'Список людей'
    }
    return render(request, 'index2.html', context=context)
