from django.contrib import admin
from django.urls import path

from arbitrary_name.views import index

urlpatterns = [
    path('', index),
]
